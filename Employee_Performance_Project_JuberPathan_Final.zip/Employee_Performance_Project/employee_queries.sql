
-- SQL queries for Employee Performance & Salary Analysis
-- Table: employee_bigdata (created from CSV import)

CREATE TABLE IF NOT EXISTS employee_bigdata (
    Emp_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Department VARCHAR(50),
    Experience_Years INT,
    Education VARCHAR(50),
    Performance_Score INT,
    MonthlyIncome FLOAT
);

-- 1. Show all employees
SELECT * FROM employee_bigdata;

-- 2. Average salary per department
SELECT Department, AVG(MonthlyIncome) AS Avg_Salary
FROM employee_bigdata
GROUP BY Department
ORDER BY Avg_Salary DESC;

-- 3. Top 10 highest paid employees
SELECT Name, Department, MonthlyIncome
FROM employee_bigdata
ORDER BY MonthlyIncome DESC
LIMIT 10;

-- 4. Experience vs Salary trend
SELECT Experience_Years, AVG(MonthlyIncome) AS Avg_Salary
FROM employee_bigdata
GROUP BY Experience_Years
ORDER BY Experience_Years;

-- 5. Top performers (Performance_Score >= 4)
SELECT Name, Department, Performance_Score, MonthlyIncome
FROM employee_bigdata
WHERE Performance_Score >= 4
ORDER BY MonthlyIncome DESC;
