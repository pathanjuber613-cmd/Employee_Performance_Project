# Employee Performance & Salary Analysis

This repository contains a complete submission-ready project for **Employee Performance & Salary Analysis** using Python, SQL, and Excel.

## Files included
- employee_data_large.csv : Synthetic dataset with 1200 employee records
- employee_analysis.py : Python script to analyze data and save plots
- Employee_Analysis_Report.xlsx : Excel workbook with raw data and pivot summaries
- employee_queries.sql : Useful MySQL queries for analysis
- Employee_Performance_Analysis_Report.docx : Project report (editable)
- README.md : This file

## How to run
1. Install Python packages: pandas, matplotlib, seaborn, openpyxl
   ```bash
   pip install pandas matplotlib seaborn openpyxl python-dotenv
   ```
2. Run the analysis script:
   ```bash
   python employee_analysis.py
   ```
3. Import `employee_data_large.csv` into MySQL or use a GUI tool (MySQL Workbench) to load data into `employee_bigdata` table.

## Author
Generated for your project. Update Author name in README and Word report before submission.


## Tableau Assets
- tableau_assets/ : PNGs of dashboard visuals + HOW_TO_OPEN_IN_TABLEAU.md

To create a Tableau .twbx file, follow the steps in the HOW_TO_OPEN_IN_TABLEAU.md file.
