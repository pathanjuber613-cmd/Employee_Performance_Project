import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
data = pd.read_csv("employee_data_large.csv")
print("Rows, Columns:", data.shape)
print(data.head())

# Basic cleaning
data = data.dropna()

# Summary stats
print(data.describe())

# Average salary by department
dept_salary = data.groupby("Department")["MonthlyIncome"].mean().sort_values(ascending=False)
print("\nAverage Salary by Department:\n", dept_salary)

# Save dept salary to CSV
dept_salary.to_csv("avg_salary_by_department.csv")

# Experience vs Salary correlation
corr = data["Experience_Years"].corr(data["MonthlyIncome"])
print("\nCorrelation between Experience and MonthlyIncome:", corr)

# Plotting (saved as images)
plt.figure(figsize=(10,6))
sns.barplot(x=dept_salary.index, y=dept_salary.values)
plt.title("Average Monthly Income by Department")
plt.ylabel("Monthly Income (₹)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("avg_salary_by_department.png")
plt.close()

plt.figure(figsize=(10,6))
sns.scatterplot(x="Experience_Years", y="MonthlyIncome", hue="Department", data=data, s=40)
plt.title("Experience vs Monthly Income")
plt.tight_layout()
plt.savefig("experience_vs_salary.png")
plt.close()

print("Plots saved: avg_salary_by_department.png, experience_vs_salary.png")
