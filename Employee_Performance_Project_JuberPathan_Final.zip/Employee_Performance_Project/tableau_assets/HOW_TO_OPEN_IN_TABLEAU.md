Tableau Instructions

These assets include PNG images of the dashboard visuals and the CSV dataset.

To create a Tableau workbook (.twbx) with the embedded data:
1. Install Tableau Desktop or Tableau Public.
2. Open Tableau and choose 'Text File' > select employee_data_large.csv from the project folder.
3. Create the following sheets:
   - Bar chart: Department (Columns) vs AVG(MonthlyIncome) (Rows)
   - Scatter: Experience_Years (Columns) vs MonthlyIncome (Rows); color by Department
   - Pie chart: Performance_Score (use 'Show Me' > pie)
   - Box plot: Education (Columns) vs MonthlyIncome (Rows) > Show Me > Box-and-Whisker Plot
4. Go to Dashboard > New Dashboard. Drag the sheets into a clean layout. Add filters for Department and Education.
5. To save as a packaged workbook with data embedded: File > Save As > choose .twbx format.

If you want, you can open the provided PNGs directly (avg_salary_by_department.png, experience_vs_salary.png, 
experience_vs_salary.png, performance_distribution.png, education_vs_salary_boxplot.png) to include in your report.

Note: Creating a .twbx file requires Tableau software which is not available in this environment. 
We provide these instructions and ready visuals so you can create the .twbx file locally in minutes.